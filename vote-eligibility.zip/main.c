/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int age;
    printf("Enter the age");
    scanf("%d",&age);
    if(age>=18)
    {
    printf("Eligible for vote");
    }
    else{
        printf(" Not eligible for vote");
    }

    return 0;
}