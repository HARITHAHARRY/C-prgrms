#include <stdio.h>

int main()
{
    int age;
    printf("Enter the number");
    scanf("%d",&age);
    (age>=0)?(printf("Number is positive")):(printf("Number is negative"));
    

    return 0;
}
